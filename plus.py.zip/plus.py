#-*- coding:utf-8 -*-
import requests
import datetime
from bs4 import BeautifulSoup

news_id = {'hani':'17', 'omn':'4', 'chosun': '200', 'joongang': '8'}
news_tend = {'hani':'0', 'omn':'0', 'chosun': '1', 'joongang': '1'} # 0 : 진보, 1 : 보수
dt = datetime.datetime.now()
delta = datetime.timedelta(days=1)

def getTitleList(news_id, date):

    titles = []
    page = 1
    while True:
        req = requests.get('http://media.daum.net/cp/' + news_id + '?page='
                            + str(page) + '&regDate=' + date + '&cateId=1002')

        soup = BeautifulSoup(req.content, 'html.parser', from_encoding='utf-8')

        raw_titles = soup.find_all("strong", {"class": "tit_thumb"})
        raw_titles = raw_titles[:-2]
        if len(raw_titles) is 0:
            break

        for raw_title in raw_titles:
            title = str(raw_title).split('">')[2].split('</a>')[0]
            titles.append(title)

        page += 1

    return titles

f = open('newsis.txt', 'w')
loading = 0
id = 222222
f.write('id\tdocument\tlabel\n')
number = 10
i = 0

while i is not number:
    print('num' + ' ' + str(i))
    date = dt.strftime('%Y%m%d')

    t = getTitleList('21', date)

    for title in t:
        f.write(str(id) + '\t' + title + '\t' + '0' + '\n')
        id += 1

    dt = dt - delta
    i += 1

f.close()
